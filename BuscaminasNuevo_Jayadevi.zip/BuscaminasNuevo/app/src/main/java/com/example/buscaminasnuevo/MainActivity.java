package com.example.buscaminasnuevo;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    static final int ACTIV_JUEGO = 0;
    public static AlmacenPuntuaciones almacen=new AlmacenPuntuaciones();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.configuracion) {
            lanzarConfiguracion(null);
            return true;
        }
        if (id == R.id.puntuacion) {
            lanzarPuntuacion(null);
            return true;
        }
        if (id == R.id.jugar) {
            lanzarJuego(null);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void lanzarJuego(View view) {
        Intent i = new Intent(this, Juego.class);
        startActivityForResult(i, ACTIV_JUEGO);
    }
    public void lanzarConfiguracion (View view){
        Intent i= new Intent(this, PreferenciasActivity.class);
        startActivityForResult(i,ACTIV_JUEGO);
    }
    public void lanzarPuntuacion (View view){
        Intent i= new Intent(this, Puntuaciones.class);
        startActivity(i);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //  startActivityForResult();
        if (requestCode == ACTIV_JUEGO && resultCode == RESULT_OK && data != null) {
            int puntuacion = data.getExtras().getInt("puntuacion");
            String nivel = PreferenceManager.getDefaultSharedPreferences(this).getString("niveles","0");
            if (nivel.equals("0")) {
                nivel="Básico";
            }else
            if (nivel.equals("1")) {
                nivel="Intermedio";
            } else
            if (nivel.equals("2")) {
                nivel="Avanzado";
            } else
                nivel="Personalizado";
           // Mejor leer nombre desde un AlertDialog.Builder o preferencias
            almacen.guardarPuntuacion(puntuacion, nivel);
            lanzarPuntuacion(null);
        }
    }

}
