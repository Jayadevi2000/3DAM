package com.example.buscaminasnuevo;

public class Puntuacion {
    private int tiempo;
    private String nombre;
    private long fecha;

    public Puntuacion(int puntos, String nombre) {
        this.tiempo = puntos;
        this.nombre = nombre;
    }

    public int getPuntos() {
        return tiempo;
    }

    public void setPuntos(int tiempo) {
        this.tiempo = tiempo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
