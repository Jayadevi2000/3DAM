package com.example.buscaminasnuevo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.EmbossMaskFilter;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class Juego extends Activity implements View.OnTouchListener {
    private FondoJuego fondo;
    int x, y;
    private Celda[][] casilla;
    private boolean activo = true;
    int filas, columnas, minas, totalceldas;
    boolean sonido = false;
    int idPerder, idGanar, idDestapar;
    SoundPool soundPool;
    private int tiempo = 0;
    private long empieza, termina;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        empieza = System.currentTimeMillis();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tablero);
        ImageView imagen = (ImageView) findViewById(R.id.carita);
        imagen.setImageResource(R.drawable.esperar);
        LinearLayout layout = (LinearLayout) findViewById(R.id.layout2);
        fondo = new FondoJuego(this);
        fondo.setOnTouchListener(this);
        layout.addView(fondo);
        soundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        Context context = this;
        idPerder = soundPool.load(context, R.raw.perder, 0);
        idGanar = soundPool.load(context, R.raw.ganar, 0);
        idDestapar = soundPool.load(context, R.raw.destapar, 0);
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        sonido = pref.getBoolean("sonidos", false);

        this.crearTablero();
        this.situarBombasInicio();
        this.rellenarTablero();
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (activo)
            for (int i = 0; i < filas; i++) {
                for (int j = 0; j < columnas; j++) {
                    if (casilla[i][j].dentro((int) event.getX(), (int) event.getY())) {
                        casilla[i][j].destapado = true;
                        if (casilla[i][j].contenido == 9) {
                            if (sonido)
                                soundPool.play(idPerder, 1, 1, 1, 0, 1);
                            //tocamos una bomba
                            activo = false;
                            //aquí cambio la cara a triste
                            ImageView imagen = (ImageView) findViewById(R.id.carita);
                            imagen.setImageResource(R.drawable.perder);
                        } else if (casilla[i][j].contenido == 0) {
                            if (sonido)
                                soundPool.play(idDestapar, 1, 1, 1, 0, 1);
                            recorrer(i, j);
                        }
                        fondo.invalidate();
                    }
                }
            }
        if (fin() && activo) {
            if (sonido)
                soundPool.play(idGanar, 1, 1, 1, 0, 1);
            activo = false;
            ImageView imagen = (ImageView) findViewById(R.id.carita);
            imagen.setImageResource(R.drawable.ganar);
            termina = System.currentTimeMillis();
            tiempo = (int) (termina - empieza) / 1000;
            salir();
        }
        return true;
    }


    public void reiniciar(View v) {
        crearTablero();
        empieza=System.currentTimeMillis();
        ImageView imagen = (ImageView) findViewById(R.id.carita);
        imagen.setImageResource(R.drawable.esperar);
        this.situarBombasInicio();
        this.rellenarTablero();
        activo = true;
        fondo.invalidate();
    }


    private void ponercoloralnumero(Paint numero, int valor) {

        switch (valor) {
            case 1:
                numero.setARGB(255, 0, 0, 255);
                //texto azul
                break;
            case 2:
                numero.setARGB(255, 0, 200, 0);
                //texto verde
                break;
            case 3:
                numero.setARGB(255, 255, 0, 0);
                //texto rojo
                break;
            case 4:
                numero.setARGB(255, 0, 0, 128);
                //texto azul oscuro
                break;
            case 5:
                numero.setARGB(255, 128, 0, 0);
                //texto marron
                break;
            case 6:
                numero.setARGB(255, 0, 128, 128);
                //texto verdeturquesa
                break;
            case 7:
                numero.setARGB(255, 25, 25, 25);
                //texto negroclaro
                break;
            case 8:
                numero.setARGB(255, 0, 255, 255);
                //texto azulclaro
                break;

        }


    }

    private void crearTablero(){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        //asignamos numero de filas y columnas para el juego
        if (pref.getString("niveles", "0").equals("0")) {
            filas = 8;
            columnas = 8;
            minas = 10;
            totalceldas = 64;
        }
        if (pref.getString("niveles", "0").equals("1")) {
            filas = 16;
            columnas = 16;
            minas = 40;
            totalceldas = 256;
        }
        if (pref.getString("niveles", "0").equals("2")) {
            filas = 30;
            columnas = 16;
            minas = 99;
            totalceldas = 480;
        }
        //Toast.makeText(Juego.this, "Creando las casillas", Toast.LENGTH_LONG).show();
        casilla = new Celda[filas][columnas];

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                casilla[i][j] = new Celda();
            }
        }


    }
    private void situarBombasInicio() {
        int cantidad = minas;
//se ha leido de preferencias (en funcion del nivel escogido) la cantidad de bombas
        do {
            int fila = (int) (Math.random() * (filas-1));
            int columna = (int) (Math.random() * (columnas-1));
            if (casilla[fila][columna].contenido == 0) {
                casilla[fila][columna].contenido = 9;
                cantidad--;
            }
        } while (cantidad != 0);
    }

    private boolean fin() {
        int celdasdestapadas = minas;
        for (int i = 0; i < filas; i++)
            for (int j = 0; j < columnas; j++)
                if (casilla[i][j].destapado)
                    celdasdestapadas++;
        if (celdasdestapadas == totalceldas)
// total del celdas que hay en el tablero en funcion del nivel escogido
            return true;
        else
            return false;
    }

    private void rellenarTablero() {
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (casilla[i][j].contenido == 0) {
                    int cant = contarBombasTocadas(i, j);
                    casilla[i][j].contenido = cant;
                }
            }
        }
    }

    int contarBombasTocadas(int fila, int columna) {
        int total = 0;
        if (fila - 1 >= 0 && columna - 1 >= 0) {
            if (casilla[fila - 1][columna - 1].contenido == 9)
                total++;
        }
        if (fila - 1 >= 0) {
            if (casilla[fila - 1][columna].contenido == 9)
                total++;
        }
        if (fila - 1 >= 0 && columna + 1 < columnas) {
            if (casilla[fila - 1][columna + 1].contenido == 9)
                total++;
        }
        if (columna + 1 < columnas) {
            if (casilla[fila][columna + 1].contenido == 9)
                total++;
        }
        if (fila + 1 < filas && columna + 1 < columnas) {
            if (casilla[fila + 1][columna + 1].contenido == 9)
                total++;
        }
        if (fila + 1 < filas) {
            if (casilla[fila + 1][columna].contenido == 9)
                total++;
        }
        if (fila + 1 < filas && columna - 1 >= 0) {
            if (casilla[fila + 1][columna - 1].contenido == 9)
                total++;
        }
        if (columna - 1 >= 0) {
            if (casilla[fila][columna - 1].contenido == 9)
                total++;
        }
        return total;
    }

    private void recorrer(int fil, int col) {
        if (fil >= 0 && fil < filas && col >= 0 && col < columnas) {
            if (casilla[fil][col].contenido == 0) {
//si esa celda no toca ninguna bomba:
//el contenido mayor que los numeros que estamos utilizando
//para no seguir recorriendolo continuamente
                casilla[fil][col].destapado = true;
                casilla[fil][col].contenido = 50;
                recorrer(fil, col + 1);
                recorrer(fil, col - 1);
                recorrer(fil + 1, col);
                recorrer(fil - 1, col);
                recorrer(fil - 1, col - 1);
                recorrer(fil - 1, col + 1);
                recorrer(fil + 1, col + 1);
                recorrer(fil + 1, col - 1);
            } else if (casilla[fil][col].contenido >= 1
                    && casilla[fil][col].contenido < 9) {
//si toca alguna bomba la destapamos y dejamos de recorrer
                casilla[fil][col].destapado = true;
            }
        }
    }

    private void salir() {
        Bundle bundle = new Bundle();
        bundle.putInt("puntuacion", tiempo);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        this.setResult(Activity.RESULT_OK, intent);
        this.finish();
    }


    class FondoJuego extends View {
        public FondoJuego(Context context) {
            super(context);
        }

        protected void onDraw(Canvas canvas) {
            canvas.drawRGB(130, 130, 130);
            int ancho = fondo.getWidth();

            int anchocuadrado = ancho / filas;
            if (anchocuadrado > 50) {
//                Toast.makeText(Juego.this, "anchocuadrado" + anchocuadrado, Toast.LENGTH_LONG).show();
                //CELDAS
                Paint paint = new Paint();
                paint.setTextSize(20);

                //NUMEROS
                Paint numero = new Paint();
                numero.setTextSize(anchocuadrado/2);
                //modificar en función del tamaño
                numero.setTypeface(Typeface.DEFAULT_BOLD);


                //LINEAS DE DIVISIÓN ENTRE CELDAS
                Paint paintlinea1 = new Paint();
                paintlinea1.setARGB(255, 180, 180, 180);
                //linea blanca

                int filaact = 0;
                for (int j = 0; j < columnas; j++) {
                    for (int i = 0; i < filas; i++) {

                        casilla[i][j].fijarxy(i * anchocuadrado, filaact, anchocuadrado);
                        if (!casilla[i][j].destapado) {
                            paint.setARGB(255, 230, 230, 230);
                            /////CELDAS CON RELIEVE ANTES DE SER DESTAPADAS/////
                            //Set the direction of the light source
                            float[] direction = new float[]{1, 1, 1};
                            //set de Ambient light level
                            float light = 0.4f;
                            //choose a level of specularity to apply
                            float specular = 20;
                            //apply a level of blur to apply to the mask
                            float blur = 7f;
                            EmbossMaskFilter relieve = new EmbossMaskFilter(direction, light, specular, blur);
                            paint.setMaskFilter(relieve);
                        } else {
                            paint.setARGB(255, 230, 230, 230);
                            //CELDAS SIN RELIEVE CUANDO SON DESTAPADAS
                            //Set the direction of the light source
                            float[] direction = new float[]{0, 0, 0};
                            //set de Ambient light level
                            float light = 0f;
                            //choose a level of specularity to apply
                            float specular = 0;
                            //apply a level of blur to apply to the mask
                            float blur = 0f;
                            EmbossMaskFilter sinrelieve = new EmbossMaskFilter(direction, light, specular, blur);
                            paint.setMaskFilter(sinrelieve);

                        }
                        canvas.drawRect(i * anchocuadrado, filaact, i * anchocuadrado
                                + anchocuadrado - 2, filaact + anchocuadrado - 2, paint);
                        // linea blanca
                        canvas.drawLine(i * anchocuadrado, filaact, i * anchocuadrado
                                + anchocuadrado, filaact, paintlinea1);
                        canvas.drawLine(i * anchocuadrado + anchocuadrado - 1, filaact, i
                                        * anchocuadrado + anchocuadrado - 1, filaact + anchocuadrado,
                                paintlinea1);

                        if (casilla[i][j].contenido >= 1 && casilla[i][j].contenido <= 8 && casilla[i][j].destapado) {
                            ponercoloralnumero(numero, casilla[i][j].contenido);
                            canvas.drawText(
                                    String.valueOf(casilla[i][j].contenido), i * anchocuadrado + (anchocuadrado / 2) - columnas,
                                    filaact + anchocuadrado / 2, numero);
                            //CREO QUE ESTÁ DIBUJANDO EN EL CENTRO DE LA CELDA, CALCULOS ABSOLUTOS ERROR!!!!!!
                        }

                        if (casilla[i][j].contenido == 9 && casilla[i][j].destapado) {
                            Paint bomba = new Paint();
                            bomba.setARGB(255, 0, 0, 0);
                            canvas.drawCircle(i * anchocuadrado + (anchocuadrado / 2),
                                    filaact + (anchocuadrado / 2), anchocuadrado/3, bomba);
                            //pintar la bomba UTILIZANDO LOS MISMOS CALCULOS QUE HAGA PARA DIBUJAR LOS NUMEROS
                            //PARA QUE QUEDE EN UNA POSICION MAS O MENOS CENTRADA
                        }
                    }
                    filaact = filaact + anchocuadrado;

                }

            } else {
                Toast.makeText(Juego.this, "El terminal es demasiado pequeño para este nivel", Toast.LENGTH_LONG).show();
                finish();
            }


        }
    }
}
