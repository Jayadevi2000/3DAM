package com.example.buscaminasnuevo;

import java.util.Vector;
public class AlmacenPuntuaciones{
    private Vector<String> puntuaciones;
    public AlmacenPuntuaciones() {
        puntuaciones = new Vector<String>();
    }
    public void guardarPuntuacion(int tiempo, String nivel) {
        puntuaciones.add(0, tiempo + " segundos.  Nivel: " +nivel);
    }
    public Vector<String> listaPuntuaciones(int cantidad) {
        return puntuaciones;
    }
}
