package com.example.adivinanum;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.adivinanum.R;

public class MainActivity extends AppCompatActivity {
    int random = (int) (Math.random() * 101);
    int numIntentos=0;
    EditText textoIntroducido;
    int texto=0;
    boolean terminado;
//    private static final String STATE_NUM_ELEGIDO =
//            "numElegido";
//    private static final String
//            STATE_NUM_INTENTOS="numIntentos";
//    private static final String STATE_MENSAJE =
//            "mensajeActual";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        //Ponemos en la aplicación el layout principal para que se vincule al abrir la aplicación
        setContentView(R.layout.activity_main);
        TextView numRandom = (TextView) findViewById(R.id.adnum);
        numRandom.setText(String.valueOf(random));

        Button btn=(Button) findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    textoIntroducido = (EditText) findViewById(R.id.editTextNumber);
                    texto = Integer.parseInt(String.valueOf(textoIntroducido.getText()));
                    if (texto == random) {
                        texto=-1;
                    }

                Log.i("depurar", "" + texto);
                String mensaje = "";
                if (random > texto) {
                    mensaje = "Se ha pasado por debajo.";
                } else if (random < texto) {
                    mensaje = "Se que ha pasado por encima.";
                } else {
                    mensaje = "Ha acertado.";
                }

                TextView textoAMostrar = (TextView) findViewById(R.id.res);
                textoAMostrar.setText("" + mensaje);
                numIntentos++;
            while (texto!=-1){
                Proceso();
            }

            }
        });
    }
    private void Proceso() {
    Button btn=(Button) findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                {
                    textoIntroducido = (EditText) findViewById(R.id.editTextNumber);
                    texto = Integer.parseInt(String.valueOf(textoIntroducido.getText()));
                    if (texto == random) {
                        texto=-1;
                    }

                    Log.i("depurar", "" + texto);
                    String mensaje = "";
                    if (random > texto) {
                        mensaje = "Se ha pasado por debajo.";
                    } else if (random < texto) {
                        mensaje = "Se que ha pasado por encima.";
                    } else {
                        mensaje = "Ha acertado.";
                    }

                    TextView textoAMostrar = (TextView) findViewById(R.id.res);
                    textoAMostrar.setText("" + mensaje);
                    numIntentos++;


                }
            }
        });
    }
        @Override
        protected void onSaveInstanceState(Bundle outState) {

            super.onSaveInstanceState(outState);
            outState.putInt("Intentos",numIntentos);
            outState.putInt("Intentos",numIntentos);

        }
}