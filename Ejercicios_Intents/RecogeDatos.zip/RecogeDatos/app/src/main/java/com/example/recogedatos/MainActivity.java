package com.example.recogedatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText t1;
    EditText t2;
    String sexo;
    CheckBox edad;
    boolean bool_edad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1=(EditText)findViewById(R.id.nombre);
        t2=(EditText)findViewById(R.id.anio);
        edad=(CheckBox)findViewById(R.id.edad);

    }
    //Método para el botón aceptar
    public void Aceptar(View view){
        RadioButton rb1=(RadioButton) findViewById(R.id.radioButton1);
        RadioButton rb2=(RadioButton) findViewById(R.id.radioButton2);
     if(rb1.isChecked()) {
         sexo = "Masculino";
     }else if(rb2.isChecked()){
         sexo="Femenino";
     }else{
         sexo="Campo vacío";
     }
        if(edad.isChecked()){
            bool_edad=true;
        }else{
            bool_edad=false;
        }

        String miNombre=t1.getText().toString();
        String anio_nac=String.valueOf(t2.getText());
        String mayor_edad=String.valueOf(bool_edad);
       Toast.makeText(this, "Tu nombre es : "+miNombre, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "Tu año de nacimiento es : "+anio_nac, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, sexo, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, mayor_edad, Toast.LENGTH_SHORT).show();

        Intent i=new Intent(MainActivity.this, VerficaDatos.class);
       i.putExtra("Nombre", t1.getText().toString());
       int otro=Integer.parseInt(String.valueOf(t2.getText()));
        i.putExtra("Anio", otro);
       i.putExtra("Sexo", sexo);
        Log.d("BOOLEANOS","antes");
        i.putExtra("Mayor",mayor_edad);
        Log.d("BOOLEANOS","DESPUÉS");

        startActivity(i);
    }
}