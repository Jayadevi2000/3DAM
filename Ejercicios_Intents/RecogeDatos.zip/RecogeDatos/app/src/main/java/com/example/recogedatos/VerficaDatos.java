package com.example.recogedatos;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class VerficaDatos extends AppCompatActivity {
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.datos_recogidos);
            TextView t1=(TextView)findViewById(R.id.nombre);
            TextView t2=(TextView)findViewById(R.id.anio);
            TextView t3=(TextView)findViewById(R.id.sexo);
            TextView t4=(TextView)findViewById(R.id.mayorEdad);

                String dato_nombre=getIntent().getStringExtra("Nombre");
                t1.setText("Nombre : "+dato_nombre);

                int dato_anio=getIntent().getIntExtra("Anio",0);
                t2.setText("Año de nacimiento : "+dato_anio);

                String dato_sexo=getIntent().getStringExtra("Sexo");
                t3.setText("Sexo : "+dato_sexo);

            Log.d("PRUEBA","antes");
                String mayor=getIntent().getStringExtra("Mayor");
                t4.setText("Mayor de edad : "+mayor);
            Log.d("PRUEBA","después");

        }
        public void Corregir(View view){
            Intent i=new Intent(VerficaDatos.this, MainActivity.class);
            startActivity(i);
        }

}
