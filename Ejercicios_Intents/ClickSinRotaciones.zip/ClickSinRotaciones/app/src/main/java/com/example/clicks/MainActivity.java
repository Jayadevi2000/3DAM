package com.example.clicks;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public int contador=0;
    private final static String STATE_NUM_VECES = "contador";
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState != null)
        {
            contador =savedInstanceState.getInt(STATE_NUM_VECES);
            if (contador != 0)
            {
                Button b = findViewById(R.id.button);
                b.setText(getEtiquetaBoton());
            }
        }
    }

    private String getEtiquetaBoton()
    {
        android.content.res.Resources res =
                getResources();
        String numPulsados;
        numPulsados = res.getQuantityString(
                R.plurals.numPulsaciones, contador, contador);
        return numPulsados;
    }

    @Override
    public void onSaveInstanceState(Bundle outSate)
    {
        super.onSaveInstanceState(outSate);
        outSate.putInt(STATE_NUM_VECES,
                contador);
    }

    public void incrementar(View v)
    {
        ++contador;
        Button b = (Button) v;
        b.setText(getEtiquetaBoton());
    }

}