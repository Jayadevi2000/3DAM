package com.example.clicks;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public int contador;
    TextView texto;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        texto=(TextView) findViewById(R.id.contador);
        contador=0;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(savedInstanceState!=null){
            contador=savedInstanceState.getInt("clicks");
            texto.setText("Has pulsado "+contador+" veces");
            android.util.Log.i("info",
                    "onCreate(" + savedInstanceState + ")");

        }
    }
    protected void onSaveInstanceState(Bundle outInstance) {
        super.onSaveInstanceState(outInstance);
        outInstance.putInt("clicks",contador);
        android.util.Log.i("info",
                "onSaveInstanceState");
    }

    public void incrementar(View vista){
        contador++;
        muestraClicks();
    }
    public void muestraClicks(){
        texto=(TextView) findViewById(R.id.contador);
        texto.setText("Has pulsado "+contador+" veces");
    }
}