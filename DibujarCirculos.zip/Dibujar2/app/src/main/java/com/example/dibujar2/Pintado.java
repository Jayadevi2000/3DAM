package com.example.dibujar2;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

class Pintado extends View
{
    public Pintado(Context context)
    {
        super(context);
    }
    protected void onDraw(Canvas canvas)
    {
        canvas.drawRGB(255, 255, 255);
        int ancho = canvas.getWidth();
        int alto = canvas.getHeight();
        Paint pincel1 = new Paint();
        pincel1.setStrokeWidth(4);
        pincel1.setARGB(255, 255, 0, 0);
        pincel1.setStyle(Paint.Style.STROKE);
        for (int f = 0; f < 10; f++) {
            canvas.drawCircle(ancho / 2, alto / 2, f * 15, pincel1);
        }
    }
}
