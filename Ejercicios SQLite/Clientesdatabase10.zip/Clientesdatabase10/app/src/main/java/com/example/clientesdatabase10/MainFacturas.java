package com.example.clientesdatabase10;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Debug;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainFacturas extends AppCompatActivity {
    private EditText et1, et2, et3, et4;;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facturas);

        // ponemos
        et1=(EditText) findViewById(R.id.num);
        et2=(EditText) findViewById(R.id.dni);
        et3=(EditText) findViewById(R.id.concepto);
        et4=(EditText) findViewById(R.id.valor);
        Button button=(Button)findViewById(R.id.muestraFacturas);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Clientes1BBDD admin = new Clientes1BBDD(MainFacturas.this,

                        "administracion", null, 1);

                SQLiteDatabase bd = admin.getWritableDatabase();

                String num = et1.getText().toString();
                String dni = et2.getText().toString();
                String concepto = et3.getText().toString();
                String valor = et4.getText().toString();


                // los inserto en la base de datos
                Cursor fila = bd.rawQuery("select dni from clientes where dni="+dni,null);
                if(fila.moveToFirst()){

                    ContentValues registro = new ContentValues();

                    registro.put("num", num);
                    registro.put("dni", dni);
                    registro.put("concepto", concepto);
                    registro.put("valor", valor);

                    // los inserto en la base de datos
                    bd.insert("facturas", null, registro);
                    Toast.makeText(MainFacturas.this, "Datos del usuario cargados", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(MainFacturas.this, "No existe una factura con dicho dni", Toast.LENGTH_SHORT).show();

                }




                bd.close();

                // ponemos los campos a vacío para insertar el siguiente usuario
                et1.setText(""); et2.setText(""); et3.setText(""); et4.setText("");

                Toast.makeText(MainFacturas.this, "Datos del usuario cargados", Toast.LENGTH_SHORT).show();

            }
        });

        Button button1=(Button)findViewById(R.id.volver);
        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i=new Intent(MainFacturas.this, MainActivity.class);
                startActivity(i);
            }
        });
    }

}
