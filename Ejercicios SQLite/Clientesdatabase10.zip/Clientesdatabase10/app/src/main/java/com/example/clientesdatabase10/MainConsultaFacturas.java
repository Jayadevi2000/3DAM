package com.example.clientesdatabase10;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainConsultaFacturas extends AppCompatActivity {
    private TextView et1, et2, et3, et4;;
private EditText dni_et;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultafacturas);
    dni_et=(EditText)findViewById(R.id.dni);
        et1=(TextView) findViewById(R.id.num);
        et2=(TextView) findViewById(R.id.muestradni);
        et3=(TextView) findViewById(R.id.concepto);
        et4=(TextView) findViewById(R.id.valor);
        Button button=(Button)findViewById(R.id.muestraFacturas);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Clientes1BBDD admin = new Clientes1BBDD(MainConsultaFacturas.this,

                        "administracion", null, 1);

                SQLiteDatabase bd = admin.getWritableDatabase();

                String dni = dni_et.getText().toString();

                // los inserto en la base de datos
                Cursor fila = bd.rawQuery("select num,dni_cliente,concepto,valor from facturas where dni="+dni,null);
                if(fila.moveToFirst()){
                    et1.setText(fila.getString(0));
                    et2.setText(fila.getString(1));
                    et3.setText(fila.getString(2));
                    et4.setText(fila.getString(3));
                    Toast.makeText(MainConsultaFacturas.this, "Datos del usuario cargados", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(MainConsultaFacturas.this, "No existe una factura con dicho dni", Toast.LENGTH_SHORT).show();

                }

                bd.close();

                // ponemos los campos a vacío para insertar el siguiente usuario


            }
        });

        Button button1=(Button)findViewById(R.id.volver);
        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i=new Intent(MainConsultaFacturas.this, MainActivity.class);
                startActivity(i);
            }
        });
    }

}
