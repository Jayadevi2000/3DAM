package com.example.clientesdatabase10;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainClientes extends AppCompatActivity {
    private EditText et1, et2, et3, et4;;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clientes);

        et1=(EditText) findViewById(R.id.dni);
        et2=(EditText) findViewById(R.id.nombre);
        et3=(EditText) findViewById(R.id.direccion);
        et4=(EditText) findViewById(R.id.telefono);
        Button button=(Button)findViewById(R.id.creaCliente);
         Button button1=(Button)findViewById(R.id.volver);
        button1.setOnClickListener(new View.OnClickListener() {
                                       public void onClick(View v) {
                                           Intent i=new Intent(MainClientes.this, MainActivity.class);
                                           startActivity(i);
                                       }
                                   });

        button.setOnClickListener(new View.OnClickListener() {
                                      public void onClick(View v) {

                                          Clientes1BBDD admin = new Clientes1BBDD(MainClientes.this,

                                                  "administracion", null, 1);

                                          SQLiteDatabase bd = admin.getWritableDatabase();

                                          String dni = et1.getText().toString();
                                          String nombre = et2.getText().toString();
                                          String direccion = et3.getText().toString();
                                          String telefono = et4.getText().toString();

                                          ContentValues registro = new ContentValues();

                                          registro.put("dni", dni);
                                          registro.put("nombre", nombre);
                                          registro.put("direccion", direccion);
                                          registro.put("telefono", telefono);

                                          // los inserto en la base de datos
                                          bd.insert("clientes", null, registro);

                                          bd.close();

                                          // ponemos los campos a vacío para insertar el siguiente usuario
                                          et1.setText(""); et2.setText(""); et3.setText(""); et4.setText("");

                                          Toast.makeText(MainClientes.this, "Datos del usuario cargados", Toast.LENGTH_SHORT).show();

                                      }

    });
    }
    // Damos de alta los usuarios en nuestra aplicación
   /* public void alta(View v) {

        Clientes1BBDD admin = new Clientes1BBDD(this,

                "administracion", null, 1);

        SQLiteDatabase bd = admin.getWritableDatabase();

        String dni = et1.getText().toString();
        String nombre = et2.getText().toString();
        String direccion = et3.getText().toString();
        String telefono = et4.getText().toString();

        ContentValues registro = new ContentValues();

        registro.put("dni", dni);
        registro.put("nombre", nombre);
        registro.put("direccion", direccion);
        registro.put("telefono", telefono);

        // los inserto en la base de datos
        bd.insert("clientes", null, registro);

        bd.close();

        // ponemos los campos a vacío para insertar el siguiente usuario
        et1.setText(""); et2.setText(""); et3.setText(""); et4.setText("");

        Toast.makeText(this, "Datos del usuario cargados", Toast.LENGTH_SHORT).show();

    }*/


}