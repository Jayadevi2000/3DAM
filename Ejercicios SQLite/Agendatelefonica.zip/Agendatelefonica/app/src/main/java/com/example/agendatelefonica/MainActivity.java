package com.example.agendatelefonica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText et1, et2, et3, et4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=(EditText) findViewById(R.id.id);
        et2=(EditText) findViewById(R.id.fecha);
        et3=(EditText) findViewById(R.id.hora);
        et4=(EditText) findViewById(R.id.asunto);

    }
    public void InsertandoCitas(View view){
        AgendaBBDD admin = new AgendaBBDD(MainActivity.this,

                "agenda", null, 1);

        SQLiteDatabase bd = admin.getWritableDatabase();

        String id = et1.getText().toString();
        String fecha = et2.getText().toString();
        String hora = et3.getText().toString();
        String asunto = et4.getText().toString();
        if (id!="" || fecha!="" || hora!="" || asunto!="") {
            ContentValues registro = new ContentValues();
            if(ConsultandoCitas(view)){
                Toast.makeText(this, "La fecha y hora ya han sido escogidas", Toast.LENGTH_SHORT).show();

            }else {
                registro.put("id", id);
                registro.put("fecha", fecha);
                registro.put("hora", hora);
                registro.put("asunto", asunto);

                // los inserto en la base de datos
                bd.insert("citas", null, registro);
                Toast.makeText(this, "Datos del usuario cargados", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this, "Rellena todos los datos", Toast.LENGTH_SHORT).show();

        }
        bd.close();

        // ponemos los campos a vacío para insertar el siguiente usuario
        et1.setText("");
        et2.setText("");
        et3.setText("");
        et4.setText("");

    }

    public boolean ConsultandoCitas(View view){
        boolean valor=false;
        AgendaBBDD admin = new AgendaBBDD(MainActivity.this,

                "agenda", null, 1);

        SQLiteDatabase bd = admin.getWritableDatabase();

        String id = et1.getText().toString();
        String fecha = et2.getText().toString();
        String hora = et3.getText().toString();
        String asunto = et4.getText().toString();
        if (fecha!="" || hora!="") {
            Cursor fila=bd.rawQuery("select id,asunto from citas where fecha = '"+fecha+"' and hora ='"+hora+"'",null);
            if (fila.moveToFirst()){
                et1.setText(fila.getString(0));
                et4.setText(fila.getString(1));
                valor=true;
            }else{
                Toast.makeText(this, "No hay datos sobre esta fecha y hora", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this, "Rellena los datos de fecha y hora", Toast.LENGTH_SHORT).show();
        }
        bd.close();
        return valor;
    }

    public void ModificandoCitas(View view){
        AgendaBBDD admin = new AgendaBBDD(MainActivity.this,

                "agenda", null, 1);

        SQLiteDatabase bd = admin.getWritableDatabase();

        String id = et1.getText().toString();
        String fecha = et2.getText().toString();
        String hora = et3.getText().toString();
        String asunto = et4.getText().toString();
        if (fecha!="" || hora!="" ) {
                ContentValues registro = new ContentValues();

                registro.put("id", id);
                registro.put("fecha", fecha);
                registro.put("hora", hora);
                registro.put("asunto", asunto);
                int cant=bd.update("citas",registro , "fecha='"+fecha+"' and hora ='"+hora+"'",null);
                if(cant==1){
                    Toast.makeText(this, "Datos del usuario cargados", Toast.LENGTH_SHORT).show();
                }else{
                Toast.makeText(this, "No existe esa fecha y hora", Toast.LENGTH_SHORT).show();

                 }
        }else{
            Toast.makeText(this, "Rellena todos los datos", Toast.LENGTH_SHORT).show();

        }
        bd.close();

        // ponemos los campos a vacío para insertar el siguiente usuario
        et1.setText("");
        et2.setText("");
        et3.setText("");
        et4.setText("");

    }

    public void BorrandoCitas(View view){
        AgendaBBDD admin = new AgendaBBDD(MainActivity.this,

                "agenda", null, 1);

        SQLiteDatabase bd = admin.getWritableDatabase();

        String id = et1.getText().toString();
        String fecha = et2.getText().toString();
        String hora = et3.getText().toString();
        String asunto = et4.getText().toString();
        if (fecha!="" || hora!="" ) {
            ContentValues registro = new ContentValues();

            registro.put("id", id);
            registro.put("fecha", fecha);
            registro.put("hora", hora);
            registro.put("asunto", asunto);
            int cant=bd.delete("citas" , "fecha='"+fecha+"' and hora ='"+hora+"'",null);
            if(cant==1){
                Toast.makeText(this, "Datos del usuario borrados", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this, "No existe esa fecha y hora", Toast.LENGTH_SHORT).show();

            }
        }else{
            Toast.makeText(this, "Rellena todos los datos", Toast.LENGTH_SHORT).show();

        }
        bd.close();

        // ponemos los campos a vacío para insertar el siguiente usuario
        et1.setText("");
        et2.setText("");
        et3.setText("");
        et4.setText("");

    }



}