package com.example.actividadesvarias;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Ciudad extends Activity implements AdapterView.OnItemSelectedListener {
    Spinner s2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ciudades);
        Spinner s1 = (Spinner) findViewById(R.id.spinner2);
     s2 = (Spinner) findViewById(R.id.spinner3);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                Ciudad.this,
                R.array.array_paises,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s1.setAdapter(adapter);
      s1.setOnItemSelectedListener(Ciudad.this);


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        //Spinner s2 = (Spinner) findViewById(R.id.spinner3);
        int[] paises = {R.array.ciudades_Espana, R.array.ciudades_Alemania, R.array.ciudades_Belgica};

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                Ciudad.this,
                paises[position],
                android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s2.setAdapter(adapter);
       seleccionados1();
       // Toast.makeText(Ciudad.this,paises[position], Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void seleccionados1() {
        Spinner s1 = (Spinner) findViewById(R.id.spinner2);
  //      Spinner s2 = (Spinner) findViewById(R.id.spinner3);
        TextView t1=(TextView) findViewById(R.id.textView2);
        String seleccionado1 = s1.getItemAtPosition(s1.getSelectedItemPosition()).toString();
        String seleccionado2 = s2.getItemAtPosition(s2.getSelectedItemPosition()).toString();
        if (seleccionado1.equals("Espana")) {
            if (seleccionado2.equals("Guadalupe")){
                t1.setText("País España, ciudad Guadalupe");
               }
            if (seleccionado2.equals("Lastras"));
                    t1.setText("País España, ciudad Lastras");
            if (seleccionado2.equals("Madrid")) {
                t1.setText("País España, ciudad Madrid");
            }
        } else if (seleccionado1.equals("Alemania")) {
            if (seleccionado2.equals("Berlin")) {
                t1.setText("País Alemania, ciudad Berlin");
            }
            if (seleccionado2.equals("Füssen")) {
                t1.setText("País Alemania, ciudad Füssen");
            }
            if (seleccionado2.equals("Köhl und Bamberg")) {

                    t1.setText("País Alemania, ciudad Köhl und Bamberg");

            }
        } else if (seleccionado1.equals("Belgica")) {
            if (seleccionado2.equals("Brujas")) {
                t1.setText("País Belgica, ciudad Brujas");
            }
            if (seleccionado2.equals("Gante")) {
                t1.setText("País Belgica, ciudad Gante");
            }
            if (seleccionado2.equals("Ambere")) {
                    t1.setText("País Belgica, ciudad Ambere");
            }

        }


    }
}