package com.example.actividadesvarias;

import android.app.Activity;
import android.os.Bundle;

public class ej1 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ej1);
    }
}
