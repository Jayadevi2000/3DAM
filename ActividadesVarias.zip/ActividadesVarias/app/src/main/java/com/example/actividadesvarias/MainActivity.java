package com.example.actividadesvarias;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button ac2;
    Button ac3;
    TextView ac1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ac2=(Button)findViewById(R.id.button6);
        ac3=(Button)findViewById(R.id.button5);
        ac1=(TextView) findViewById(R.id.textView4);
       ac1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in1=new Intent(MainActivity.this, ej1.class);
                startActivity(in1);
            }
        });
        ac2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in2=new Intent(MainActivity.this, Calcular.class);
                startActivity(in2);
            }
        });
        ac3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in3=new Intent(MainActivity.this, Ciudad.class);
                startActivity(in3);
            }
        });
    }
    public void accion2(View view){
        Intent in2=new Intent(MainActivity.this, Calcular.class);
        startActivity(in2);
    }
}