package com.example.buscaminasv10;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

public class Jugando extends Activity implements View.OnTouchListener{
 Tablero t;
  float x = 0;
    float y = 0;
    Casilla casillas[][];
    int cont=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buscamina);
        LinearLayout layout = (LinearLayout) findViewById(R.id.lugar_juego);
        t = new Tablero(this);
  t.setOnTouchListener((View.OnTouchListener) this);
        layout.addView(t);
//        for (int f = 0; f < 8; f++) {
//            for (int c = 0; c < 8; c++) {
//                casillas[f][c] = new Casilla();
//            }
//        }


    }

   @Override
    public boolean onTouch(View v, MotionEvent event) {
       LinearLayout layout = (LinearLayout) findViewById(R.id.lugar_juego);

       x = event.getX();
        y = event.getY();
            Toast.makeText(this,"haciendo onTouch", Toast.LENGTH_LONG);

            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    casillas[i][j].fijarxy(x, y, t.getWidth());
                    casillas[i][j].destapado = true;
                    cont++;
                }
            }

            return true;
//        } else {
//            return false;
//        }
    }
    public void ganador(){

                if(cont==54){ //Son 64 casillas menos 10 bombas
                    Toast.makeText(this, "GANASTE", Toast.LENGTH_SHORT).show();

                }

    }

    private void poneMinas() {
        int cantidad = 10;
        do {
            int fila = (int) (Math.random() * 8);
            int columna = (int) (Math.random() * 8);
            if (casillas[fila][columna].contenido == 0) {
                casillas[fila][columna].contenido = 1;
                cantidad--;
            }
        } while (cantidad != 0);
    }


}
