package com.example.buscaminasv10;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.view.View;

import androidx.annotation.RequiresApi;

public class Tablero extends View {
    private Casilla[][] casillas;
    public Tablero(Context context)
    {
        super(context);
    }
    protected void onDraw(Canvas canvas)
    {
       // canvas.drawRGB(255, 255, 255);
        int ancho = canvas.getWidth();
        int alto = canvas.getHeight();

        Paint pincel = new Paint();
        pincel.setStyle(Paint.Style.FILL);
        pincel.setARGB(255, 255, 255, 0);
        canvas.drawColor(Color.YELLOW);
        pincel.setStrokeWidth(4);
        pincel.setStyle(Paint.Style.FILL_AND_STROKE);

        pincel.setARGB(0, 255, 255, 255);
        //canvas.drawLine(0, 70, ancho, 70, pincel);

        casillas=new Casilla[8][8];
        pincel.setStrokeWidth(6);
        int num=ancho/8;
        int otro=alto/8;
        pincel.setColor(Color.BLUE);
        canvas.drawLine(0, 0, ancho,0, pincel);
        canvas.drawLine(0, 0, 0,alto, pincel);

        int valor_alto=0;
        int valor_ancho=0;
     for (int fila = 0; fila < 8; fila++)
        {
            valor_alto=fila*otro;
            valor_ancho=fila*num;

            for (int i=0;i<8;i++){
                casillas[fila][i].fijarxy(valor_ancho,valor_alto,ancho);
                if(casillas[fila][i].destapado){
                    pincel.setStyle(Paint.Style.FILL);
                    pincel.setColor(Color.RED);
                }else{
                    pincel.setStyle(Paint.Style.FILL);
                    pincel.setColor(Color.GREEN);
                }
            }
            canvas.drawLine(0, valor_alto, ancho,valor_alto, pincel);
            canvas.drawLine(valor_ancho, 0, valor_ancho,alto, pincel);


        }
        canvas.drawLine(0, alto, ancho,alto, pincel);
        canvas.drawLine(ancho, 0, ancho,alto, pincel);

    }

}
