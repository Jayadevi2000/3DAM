package com.example.buscaminasv10;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button configurar=(Button) findViewById(R.id.button);
        configurar.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View view)
            {
                Log.i("depurando","error en intent");
                Intent miIntent=new Intent(MainActivity.this,Configuracion.class);
                startActivity(miIntent);
            }});

        Button jugar=(Button) findViewById(R.id.btn1);
        jugar.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View view)
            {
                Log.i("depurando","error en intent");
                Intent miIntent=new Intent(MainActivity.this,Jugando.class);
                startActivity(miIntent);
            }});

    }
    public void Boton(View view){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setMessage("SALIR");
        alert.setTitle("¿Quieres salir de la aplicación?");
        alert.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }); //El segundo parámetro
        // puede ser una función OnClickListener, para realizar alguna acción.
        alert.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.d("Mensaje", "Se cancelo la acción");
            }});//Igual que el anterior pero
        //   para la otra opción.
        // alert.setNeutralButton("Opción Cancelar", null);//Tercera opción a realizar.
        alert.show();

    }
}